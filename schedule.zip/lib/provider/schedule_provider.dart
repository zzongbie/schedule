import 'package:flutter/material.dart';

enum ViewMode { monthly, weekly, daily }

class ScheduleProvider with ChangeNotifier {
  DateTime focusedDay = DateTime.now();
  DateTime? selectedDay;
  ViewMode currentViewMode = ViewMode.monthly;

  final Map<String, List<String>> departmentData = {
    'Development (개발팀)': ['정프로', '이과장', '박대리'],
    'Design (디자인팀)': ['김수석', '최주임'],
    'Marketing (마케팅팀)': ['한팀장', '송사원'],
  };

  final Map<String, bool> employeeCheckboxState = {};

  Map<DateTime, List<Map<String, dynamic>>> events = {};

  ScheduleProvider() {
    // Initialize checkboxes
    for (var employees in departmentData.values) {
      for (var emp in employees) {
        employeeCheckboxState[emp] = false;
      }
    }

    // Initialize mock events with hour (startHour) and duration (hours)
    final today = DateTime.now();
    events = {
      DateTime.utc(today.year, today.month, today.day): [
        {'name': '정프로', 'title': '주간 회의', 'color': Colors.blue, 'startHour': 10.0, 'duration': 2.0},
        {'name': '이과장', 'title': '코드 리뷰', 'color': Colors.green, 'startHour': 10.5, 'duration': 1.5}, // Overlaps with 주간 회의
        {'name': '박대리', 'title': '클라이언트 미팅', 'color': Colors.redAccent, 'startHour': 10.0, 'duration': 3.0}, // Overlaps with both
        {'name': '김수석', 'title': '디자인 시안', 'color': Colors.orange, 'startHour': 14.0, 'duration': 1.5},
        {'name': '한팀장', 'title': '마케팅 기획', 'color': Colors.purple, 'startHour': 14.5, 'duration': 2.0}, // Overlaps with 디자인 시안
      ],
      DateTime.utc(today.year, today.month, today.day + 2): [
        {'name': '김수석', 'title': '외부 강연', 'color': Colors.orange, 'startHour': 13.0, 'duration': 3.0},
      ],
      DateTime.utc(today.year, today.month, today.day + 5): [
        {'name': '한팀장', 'title': '워크샵 기획', 'color': Colors.purple, 'startHour': 11.0, 'duration': 2.0},
        {'name': '정프로', 'title': '개발팀 회식', 'color': Colors.blue, 'startHour': 18.0, 'duration': 3.0},
      ],
    };
  }

  void toggleEmployee(String emp, bool? value) {
    employeeCheckboxState[emp] = value ?? false;
    notifyListeners();
  }

  void selectDay(DateTime selected, DateTime focused) {
    selectedDay = selected;
    focusedDay = focused;
    notifyListeners();
  }

  void setViewMode(ViewMode mode) {
    currentViewMode = mode;
    notifyListeners();
  }

  List<Map<String, dynamic>> getEventsForDay(DateTime day) {
    final allEvents = events[DateTime.utc(day.year, day.month, day.day)] ?? [];
    
    bool hasSelection = employeeCheckboxState.values.any((isSelected) => isSelected);
    
    if (!hasSelection) return allEvents;
    
    return allEvents.where((event) => employeeCheckboxState[event['name']] == true).toList();
  }
}
