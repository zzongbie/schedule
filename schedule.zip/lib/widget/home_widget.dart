import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../provider/schedule_provider.dart';
import 'm_calendar.dart';
import 'w_calendar.dart';
import 't_calendar.dart';

class HomeWidget extends StatelessWidget {
  const HomeWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // 좌측 상단에 뷰 변경 버튼(Dropdown / Toggle)
        leadingWidth: 300,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16.0),
          child: Row(
            children: [
              const Text('팀 스케줄', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
              const SizedBox(width: 16),
              Consumer<ScheduleProvider>(
                builder: (context, provider, child) {
                  return ToggleButtons(
                    constraints: const BoxConstraints(minHeight: 32, minWidth: 60),
                    borderRadius: BorderRadius.circular(8.0),
                    isSelected: [
                      provider.currentViewMode == ViewMode.monthly,
                      provider.currentViewMode == ViewMode.weekly,
                      provider.currentViewMode == ViewMode.daily,
                    ],
                    onPressed: (index) {
                      if (index == 0) provider.setViewMode(ViewMode.monthly);
                      else if (index == 1) provider.setViewMode(ViewMode.weekly);
                      else if (index == 2) provider.setViewMode(ViewMode.daily);
                    },
                    children: const [
                      Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('월간')),
                      Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('주간')),
                      Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text('일간')),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
        elevation: 1,
        backgroundColor: Colors.white,
        foregroundColor: Colors.black87,
      ),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildSidebar(context),
          Expanded(
            child: Consumer<ScheduleProvider>(
              builder: (context, provider, child) {
                switch (provider.currentViewMode) {
                  case ViewMode.monthly:
                    return const MCalendar();
                  case ViewMode.weekly:
                    return const WCalendar();
                  case ViewMode.daily:
                    return const TCalendar();
                  default:
                    return const MCalendar();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSidebar(BuildContext context) {
    final provider = context.watch<ScheduleProvider>();
    
    return Container(
      width: 280,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: Colors.black12)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(
              '직원 목록 / Employees',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.indigo),
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              children: provider.departmentData.entries.map((entry) {
                return ExpansionTile(
                  initiallyExpanded: true,
                  title: Text(
                    entry.key,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  children: entry.value.map((emp) {
                    return CheckboxListTile(
                      dense: true,
                      activeColor: Colors.indigo,
                      controlAffinity: ListTileControlAffinity.leading,
                      title: Text(emp),
                      value: provider.employeeCheckboxState[emp] ?? false,
                      onChanged: (bool? value) {
                        provider.toggleEmployee(emp, value);
                      },
                    );
                  }).toList(),
                );
              }).toList(),
            ),
          ),
          // A friendly message from Frontman (Persona!)
          Container(
            padding: const EdgeInsets.all(16.0),
            color: Colors.indigo.shade50,
            child: const Row(
              children: [
                Icon(Icons.face, color: Colors.indigo),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '"정프로님, 조회하실 직원들을 선택해 주십시오! 충성!"',
                    style: TextStyle(
                      fontStyle: FontStyle.italic,
                      color: Colors.indigo,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
